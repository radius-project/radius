# Applications.Core @ 2023-10-01-preview

## Resource Applications.Core/applications@2023-10-01-preview
* **Valid Scope(s)**: Unknown
### Properties
* **apiVersion**: '2023-10-01-preview' (ReadOnly, DeployTimeConstant): The resource api version
* **id**: string (ReadOnly, DeployTimeConstant): The resource id
* **location**: string: The geo-location where the resource lives
* **name**: string (Required, DeployTimeConstant, Identifier): The resource name
* **properties**: [ApplicationProperties](#applicationproperties) (Required): Application properties
* **systemData**: [SystemData](#systemdata) (ReadOnly): Metadata pertaining to creation and last modification of the resource.
* **tags**: [TrackedResourceTags](#trackedresourcetags): Resource tags.
* **type**: 'Applications.Core/applications' (ReadOnly, DeployTimeConstant): The resource type

## Resource Applications.Core/containers@2023-10-01-preview
* **Valid Scope(s)**: Unknown
### Properties
* **apiVersion**: '2023-10-01-preview' (ReadOnly, DeployTimeConstant): The resource api version
* **id**: string (ReadOnly, DeployTimeConstant): The resource id
* **location**: string: The geo-location where the resource lives
* **name**: string (Required, DeployTimeConstant, Identifier): The resource name
* **properties**: [ContainerProperties](#containerproperties) (Required): Container properties
* **systemData**: [SystemData](#systemdata) (ReadOnly): Metadata pertaining to creation and last modification of the resource.
* **tags**: [TrackedResourceTags](#trackedresourcetags): Resource tags.
* **type**: 'Applications.Core/containers' (ReadOnly, DeployTimeConstant): The resource type

## Resource Applications.Core/environments@2023-10-01-preview
* **Valid Scope(s)**: Unknown
### Properties
* **apiVersion**: '2023-10-01-preview' (ReadOnly, DeployTimeConstant): The resource api version
* **id**: string (ReadOnly, DeployTimeConstant): The resource id
* **location**: string: The geo-location where the resource lives
* **name**: string (Required, DeployTimeConstant, Identifier): The resource name
* **properties**: [EnvironmentProperties](#environmentproperties) (Required): Environment properties
* **systemData**: [SystemData](#systemdata) (ReadOnly): Metadata pertaining to creation and last modification of the resource.
* **tags**: [TrackedResourceTags](#trackedresourcetags): Resource tags.
* **type**: 'Applications.Core/environments' (ReadOnly, DeployTimeConstant): The resource type

## Resource Applications.Core/extenders@2023-10-01-preview
* **Valid Scope(s)**: Unknown
### Properties
* **apiVersion**: '2023-10-01-preview' (ReadOnly, DeployTimeConstant): The resource api version
* **id**: string (ReadOnly, DeployTimeConstant): The resource id
* **location**: string: The geo-location where the resource lives
* **name**: string (Required, DeployTimeConstant, Identifier): The resource name
* **properties**: [ExtenderProperties](#extenderproperties) (Required): ExtenderResource portable resource properties
* **systemData**: [SystemData](#systemdata) (ReadOnly): Metadata pertaining to creation and last modification of the resource.
* **tags**: [TrackedResourceTags](#trackedresourcetags): Resource tags.
* **type**: 'Applications.Core/extenders' (ReadOnly, DeployTimeConstant): The resource type

### Function listSecrets
* **Output**: [ExtenderListSecretResponse](#extenderlistsecretresponse)
#### Parameters

## Resource Applications.Core/gateways@2023-10-01-preview
* **Valid Scope(s)**: Unknown
### Properties
* **apiVersion**: '2023-10-01-preview' (ReadOnly, DeployTimeConstant): The resource api version
* **id**: string (ReadOnly, DeployTimeConstant): The resource id
* **location**: string: The geo-location where the resource lives
* **name**: string (Required, DeployTimeConstant, Identifier): The resource name
* **properties**: [GatewayProperties](#gatewayproperties) (Required): Gateway properties
* **systemData**: [SystemData](#systemdata) (ReadOnly): Metadata pertaining to creation and last modification of the resource.
* **tags**: [TrackedResourceTags](#trackedresourcetags): Resource tags.
* **type**: 'Applications.Core/gateways' (ReadOnly, DeployTimeConstant): The resource type

## Resource Applications.Core/secretStores@2023-10-01-preview
* **Valid Scope(s)**: Unknown
### Properties
* **apiVersion**: '2023-10-01-preview' (ReadOnly, DeployTimeConstant): The resource api version
* **id**: string (ReadOnly, DeployTimeConstant): The resource id
* **location**: string: The geo-location where the resource lives
* **name**: string (Required, DeployTimeConstant, Identifier): The resource name
* **properties**: [SecretStoreProperties](#secretstoreproperties) (Required): The properties of SecretStore
* **systemData**: [SystemData](#systemdata) (ReadOnly): Metadata pertaining to creation and last modification of the resource.
* **tags**: [TrackedResourceTags](#trackedresourcetags): Resource tags.
* **type**: 'Applications.Core/secretStores' (ReadOnly, DeployTimeConstant): The resource type

### Function listSecrets
* **Output**: [SecretStoreListSecretsResult](#secretstorelistsecretsresult)
#### Parameters

## Resource Applications.Core/volumes@2023-10-01-preview
* **Valid Scope(s)**: Unknown
### Properties
* **apiVersion**: '2023-10-01-preview' (ReadOnly, DeployTimeConstant): The resource api version
* **id**: string (ReadOnly, DeployTimeConstant): The resource id
* **location**: string: The geo-location where the resource lives
* **name**: string (Required, DeployTimeConstant, Identifier): The resource name
* **properties**: [VolumeProperties](#volumeproperties) (Required): Volume properties
* **systemData**: [SystemData](#systemdata) (ReadOnly): Metadata pertaining to creation and last modification of the resource.
* **tags**: [TrackedResourceTags](#trackedresourcetags): Resource tags.
* **type**: 'Applications.Core/volumes' (ReadOnly, DeployTimeConstant): The resource type

## ACIRuntimeProperties
### Properties
* **gatewayID**: string: The ID of the gateway that is providing L7 traffic for the container

## ApplicationProperties
### Properties
* **environment**: string (Required): Fully qualified resource ID for the environment that the application is linked to
* **extensions**: [Extension](#extension)[]: The application extension.
* **provisioningState**: 'Accepted' | 'Canceled' | 'Creating' | 'Deleting' | 'Failed' | 'Provisioning' | 'Succeeded' | 'Updating' (ReadOnly): Provisioning state of the resource at the time the operation was called
* **status**: [ResourceStatus](#resourcestatus) (ReadOnly): Status of a resource.

## AuthConfig
### Properties
* **git**: [GitAuthConfig](#gitauthconfig): Authentication information used to access private Terraform modules from Git repository sources.

## AzureKeyVaultVolumePropertiesCertificates
### Properties
### Additional Properties
* **Additional Properties Type**: [CertificateObjectProperties](#certificateobjectproperties)

## AzureKeyVaultVolumePropertiesKeys
### Properties
### Additional Properties
* **Additional Properties Type**: [KeyObjectProperties](#keyobjectproperties)

## AzureKeyVaultVolumePropertiesSecrets
### Properties
### Additional Properties
* **Additional Properties Type**: [SecretObjectProperties](#secretobjectproperties)

## BicepConfigProperties
### Properties
* **authentication**: [BicepConfigPropertiesAuthentication](#bicepconfigpropertiesauthentication): Authentication information used to access private bicep registries, which is a map of registry hostname to secret config that contains credential information.

## BicepConfigPropertiesAuthentication
### Properties
### Additional Properties
* **Additional Properties Type**: [RegistrySecretConfig](#registrysecretconfig)

## CertificateObjectProperties
### Properties
* **alias**: string: File name when written to disk
* **certType**: 'certificate' | 'privatekey' | 'publickey': Represents certificate types
* **encoding**: 'base64' | 'hex' | 'utf-8': Encoding format. Default utf-8
* **format**: 'pem' | 'pfx': Represents certificate formats
* **name**: string (Required): The name of the certificate
* **version**: string: Certificate version

## ConnectionProperties
### Properties
* **disableDefaultEnvVars**: bool: default environment variable override
* **iam**: [IamProperties](#iamproperties): IAM properties
* **source**: string (Required): The source of the connection

## Container
### Properties
* **args**: string[]: Arguments to the entrypoint. Overrides the container image's CMD
* **command**: string[]: Entrypoint array. Overrides the container image's ENTRYPOINT
* **env**: [ContainerEnv](#containerenv): environment
* **image**: string (Required): The registry and image to download and run in your container
* **imagePullPolicy**: 'Always' | 'IfNotPresent' | 'Never': The image pull policy for the container
* **livenessProbe**: [HealthProbeProperties](#healthprobeproperties): Properties for readiness/liveness probe
* **ports**: [ContainerPorts](#containerports): container ports
* **readinessProbe**: [HealthProbeProperties](#healthprobeproperties): Properties for readiness/liveness probe
* **volumes**: [ContainerVolumes](#containervolumes): container volumes
* **workingDir**: string: Working directory for the container

## ContainerEnv
### Properties
### Additional Properties
* **Additional Properties Type**: [EnvironmentVariable](#environmentvariable)

## ContainerPortProperties
### Properties
* **containerPort**: int (Required): The listening port number
* **port**: int: Specifies the port that will be exposed by this container. Must be set when value different from containerPort is desired
* **protocol**: 'TCP' | 'UDP': The protocol in use by the port
* **scheme**: string: Specifies the URL scheme of the communication protocol. Consumers can use the scheme to construct a URL. The value defaults to 'http' or 'https' depending on the port value

## ContainerPorts
### Properties
### Additional Properties
* **Additional Properties Type**: [ContainerPortProperties](#containerportproperties)

## ContainerProperties
### Properties
* **application**: string (Required): Fully qualified resource ID for the application
* **connections**: [ContainerPropertiesConnections](#containerpropertiesconnections): Specifies a connection to another resource.
* **container**: [Container](#container) (Required): Definition of a container
* **environment**: string: Fully qualified resource ID for the environment that the application is linked to
* **extensions**: [Extension](#extension)[]: Extensions spec of the resource
* **identity**: [IdentitySettings](#identitysettings): IdentitySettings is the external identity setting.
* **provisioningState**: 'Accepted' | 'Canceled' | 'Creating' | 'Deleting' | 'Failed' | 'Provisioning' | 'Succeeded' | 'Updating' (ReadOnly): Provisioning state of the resource at the time the operation was called
* **resourceProvisioning**: 'internal' | 'manual': Specifies how the underlying service/resource is provisioned and managed. Available values are 'internal', where Radius manages the lifecycle of the resource internally, and 'manual', where a user manages the resource.
* **resources**: [ResourceReference](#resourcereference)[]: A collection of references to resources associated with the container
* **restartPolicy**: 'Always' | 'Never' | 'OnFailure': Restart policy for the container
* **runtimes**: [RuntimesProperties](#runtimesproperties): The properties for runtime configuration
* **status**: [ResourceStatus](#resourcestatus) (ReadOnly): Status of a resource.

## ContainerPropertiesConnections
### Properties
### Additional Properties
* **Additional Properties Type**: [ConnectionProperties](#connectionproperties)

## ContainerVolumes
### Properties
### Additional Properties
* **Additional Properties Type**: [Volume](#volume)

## DictionaryOfRecipeProperties
### Properties
### Additional Properties
* **Additional Properties Type**: [RecipeProperties](#recipeproperties)

## EnvironmentCompute
* **Discriminator**: kind

### Base Properties
* **identity**: [IdentitySettings](#identitysettings): IdentitySettings is the external identity setting.
* **resourceId**: string: The resource id of the compute resource for application environment.

### AzureContainerInstanceCompute
#### Properties
* **kind**: 'aci' (Required): Discriminator property for EnvironmentCompute.
* **resourceGroup**: string: The resource group to use for the environment.

### KubernetesCompute
#### Properties
* **kind**: 'kubernetes' (Required): Discriminator property for EnvironmentCompute.
* **namespace**: string (Required): The namespace to use for the environment.


## EnvironmentProperties
### Properties
* **compute**: [EnvironmentCompute](#environmentcompute) (Required): Represents backing compute resource
* **extensions**: [Extension](#extension)[]: The environment extension.
* **providers**: [Providers](#providers): The Cloud providers configuration.
* **provisioningState**: 'Accepted' | 'Canceled' | 'Creating' | 'Deleting' | 'Failed' | 'Provisioning' | 'Succeeded' | 'Updating' (ReadOnly): Provisioning state of the resource at the time the operation was called
* **recipeConfig**: [RecipeConfigProperties](#recipeconfigproperties): Configuration for Recipes. Defines how each type of Recipe should be configured and run.
* **recipes**: [EnvironmentPropertiesRecipes](#environmentpropertiesrecipes): Specifies Recipes linked to the Environment.
* **simulated**: bool: Simulated environment.

## EnvironmentPropertiesRecipes
### Properties
### Additional Properties
* **Additional Properties Type**: [DictionaryOfRecipeProperties](#dictionaryofrecipeproperties)

## EnvironmentVariable
### Properties
* **value**: string: The value of the environment variable
* **valueFrom**: [EnvironmentVariableReference](#environmentvariablereference): The reference to the variable

## EnvironmentVariableReference
### Properties
* **secretRef**: [SecretReference](#secretreference) (Required): This secret is used within a recipe. Secrets are encrypted, often have fine-grained access control, auditing and are recommended to be used to hold sensitive data.

## EnvironmentVariables
### Properties
### Additional Properties
* **Additional Properties Type**: string

## ExtenderProperties
### Properties
* **application**: string: Fully qualified resource ID for the application that the portable resource is consumed by (if applicable)
* **environment**: string (Required): Fully qualified resource ID for the environment that the portable resource is linked to
* **provisioningState**: 'Accepted' | 'Canceled' | 'Creating' | 'Deleting' | 'Failed' | 'Provisioning' | 'Succeeded' | 'Updating' (ReadOnly): Provisioning state of the resource at the time the operation was called
* **recipe**: [Recipe](#recipe): The recipe used to automatically deploy underlying infrastructure for a portable resource
* **resourceProvisioning**: 'manual' | 'recipe': Specifies how the underlying service/resource is provisioned and managed. Available values are 'recipe', where Radius manages the lifecycle of the resource through a Recipe, and 'manual', where a user manages the resource and provides the values.
* **secrets**: any: Any object
* **status**: [ResourceStatus](#resourcestatus) (ReadOnly): Status of a resource.
### Additional Properties
* **Additional Properties Type**: any

## Extension
* **Discriminator**: kind

### Base Properties

### AzureContainerInstanceExtension
#### Properties
* **kind**: 'aci' (Required): Discriminator property for Extension.
* **resourceGroup**: string (Required): The resource group of the application environment.

### DaprSidecarExtension
#### Properties
* **appId**: string (Required): The Dapr appId. Specifies the identifier used by Dapr for service invocation.
* **appPort**: int: The Dapr appPort. Specifies the internal listening port for the application to handle requests from the Dapr sidecar.
* **config**: string: Specifies the Dapr configuration to use for the resource.
* **kind**: 'daprSidecar' (Required): Discriminator property for Extension.
* **protocol**: 'grpc' | 'http': The Dapr sidecar extension protocol

### KubernetesMetadataExtension
#### Properties
* **annotations**: [KubernetesMetadataExtensionAnnotations](#kubernetesmetadataextensionannotations): Annotations to be applied to the Kubernetes resources output by the resource
* **kind**: 'kubernetesMetadata' (Required): Discriminator property for Extension.
* **labels**: [KubernetesMetadataExtensionLabels](#kubernetesmetadataextensionlabels): Labels to be applied to the Kubernetes resources output by the resource

### KubernetesNamespaceExtension
#### Properties
* **kind**: 'kubernetesNamespace' (Required): Discriminator property for Extension.
* **namespace**: string (Required): The namespace of the application environment.

### ManualScalingExtension
#### Properties
* **kind**: 'manualScaling' (Required): Discriminator property for Extension.
* **replicas**: int (Required): Replica count.


## GatewayHostname
### Properties
* **fullyQualifiedHostname**: string: Specify a fully-qualified domain name: myapp.mydomain.com. Mutually exclusive with 'prefix' and will take priority if both are defined.
* **prefix**: string: Specify a prefix for the hostname: myhostname.myapp.PUBLICHOSTNAMEORIP.nip.io. Mutually exclusive with 'fullyQualifiedHostname' and will be overridden if both are defined.

## GatewayProperties
### Properties
* **application**: string (Required): Fully qualified resource ID for the application
* **environment**: string: Fully qualified resource ID for the environment that the application is linked to
* **hostname**: [GatewayHostname](#gatewayhostname): Declare hostname information for the Gateway. Leaving the hostname empty auto-assigns one: mygateway.myapp.PUBLICHOSTNAMEORIP.nip.io.
* **internal**: bool: Sets Gateway to not be exposed externally (no public IP address associated). Defaults to false (exposed to internet).
* **provisioningState**: 'Accepted' | 'Canceled' | 'Creating' | 'Deleting' | 'Failed' | 'Provisioning' | 'Succeeded' | 'Updating' (ReadOnly): Provisioning state of the resource at the time the operation was called
* **routes**: [GatewayRoute](#gatewayroute)[] (Required): Routes attached to this Gateway
* **status**: [ResourceStatus](#resourcestatus) (ReadOnly): Status of a resource.
* **tls**: [GatewayTls](#gatewaytls): TLS configuration definition for Gateway resource.
* **url**: string (ReadOnly): URL of the gateway resource. Readonly

## GatewayRoute
### Properties
* **destination**: string: The URL or id of the service to route to. Ex - 'http://myservice'.
* **enableWebsockets**: bool: Enables websocket support for the route. Defaults to false.
* **path**: string: The path to match the incoming request path on. Ex - /myservice.
* **replacePrefix**: string: Optionally update the prefix when sending the request to the service. Ex - replacePrefix: '/' and path: '/myservice' will transform '/myservice/myroute' to '/myroute'
* **timeoutPolicy**: [GatewayRouteTimeoutPolicy](#gatewayroutetimeoutpolicy): Gateway route timeout policy

## GatewayRouteTimeoutPolicy
### Properties
* **backendRequest**: string: The backend request timeout in duration for the route. Cannot be greater than the request timeout.
* **request**: string: The request timeout in duration for the route. Defaults to 15 seconds.

## GatewayTls
### Properties
* **certificateFrom**: string: The resource id for the secret containing the TLS certificate and key for the gateway.
* **minimumProtocolVersion**: '1.2' | '1.3': TLS minimum protocol version (defaults to 1.2).
* **sslPassthrough**: bool: If true, gateway lets the https traffic sslPassthrough to the backend servers for decryption.

## GitAuthConfig
### Properties
* **pat**: [GitAuthConfigPat](#gitauthconfigpat): Personal Access Token (PAT) configuration used to authenticate to Git platforms.

## GitAuthConfigPat
### Properties
### Additional Properties
* **Additional Properties Type**: [SecretConfig](#secretconfig)

## HealthProbeProperties
* **Discriminator**: kind

### Base Properties
* **failureThreshold**: int: Threshold number of times the probe fails after which a failure would be reported
* **initialDelaySeconds**: int: Initial delay in seconds before probing for readiness/liveness
* **periodSeconds**: int: Interval for the readiness/liveness probe in seconds
* **timeoutSeconds**: int: Number of seconds after which the readiness/liveness probe times out. Defaults to 5 seconds

### ExecHealthProbeProperties
#### Properties
* **command**: string (Required): Command to execute to probe readiness/liveness
* **kind**: 'exec' (Required): Discriminator property for HealthProbeProperties.

### HttpGetHealthProbeProperties
#### Properties
* **containerPort**: int (Required): The listening port number
* **headers**: [HttpGetHealthProbePropertiesHeaders](#httpgethealthprobepropertiesheaders): Custom HTTP headers to add to the get request
* **kind**: 'httpGet' (Required): Discriminator property for HealthProbeProperties.
* **path**: string (Required): The route to make the HTTP request on

### TcpHealthProbeProperties
#### Properties
* **containerPort**: int (Required): The listening port number
* **kind**: 'tcp' (Required): Discriminator property for HealthProbeProperties.


## HttpGetHealthProbePropertiesHeaders
### Properties
### Additional Properties
* **Additional Properties Type**: string

## IamProperties
### Properties
* **kind**: 'azure' | 'string' (Required): The kind of IAM provider to configure
* **roles**: string[]: RBAC permissions to be assigned on the source resource

## IdentitySettings
### Properties
* **kind**: 'azure.com.workload' | 'systemAssigned' | 'systemAssignedUserAssigned' | 'undefined' | 'userAssigned' (Required): IdentitySettingKind is the kind of supported external identity setting
* **managedIdentity**: string[]: The list of user assigned managed identities
* **oidcIssuer**: string: The URI for your compute platform's OIDC issuer
* **resource**: string: The resource ID of the provisioned identity

## KeyObjectProperties
### Properties
* **alias**: string: File name when written to disk
* **name**: string (Required): The name of the key
* **version**: string: Key version

## KubernetesMetadataExtensionAnnotations
### Properties
### Additional Properties
* **Additional Properties Type**: string

## KubernetesMetadataExtensionLabels
### Properties
### Additional Properties
* **Additional Properties Type**: string

## KubernetesPodSpec
### Properties
### Additional Properties
* **Additional Properties Type**: any

## KubernetesRuntimeProperties
### Properties
* **base**: string: The serialized YAML manifest which represents the base Kubernetes resources to deploy, such as Deployment, Service, ServiceAccount, Secrets, and ConfigMaps.
* **pod**: [KubernetesPodSpec](#kubernetespodspec): A strategic merge patch that will be applied to the PodSpec object when this container is being deployed.

## OutputResource
### Properties
* **id**: string: The UCP resource ID of the underlying resource.
* **localId**: string: The logical identifier scoped to the owning Radius resource. This is only needed or used when a resource has a dependency relationship. LocalIDs do not have any particular format or meaning beyond being compared to determine dependency relationships.
* **radiusManaged**: bool: Determines whether Radius manages the lifecycle of the underlying resource.

## ProviderConfigProperties
### Properties
* **secrets**: [ProviderConfigPropertiesSecrets](#providerconfigpropertiessecrets): Sensitive data in provider configuration can be stored as secrets. The secrets are stored in Applications.Core/SecretStores resource.
### Additional Properties
* **Additional Properties Type**: any

## ProviderConfigPropertiesSecrets
### Properties
### Additional Properties
* **Additional Properties Type**: [SecretReference](#secretreference)

## Providers
### Properties
* **aws**: [ProvidersAws](#providersaws): The AWS cloud provider definition.
* **azure**: [ProvidersAzure](#providersazure): The Azure cloud provider definition.

## ProvidersAws
### Properties
* **scope**: string (Required): Target scope for AWS resources to be deployed into.  For example: '/planes/aws/aws/accounts/000000000000/regions/us-west-2'.

## ProvidersAzure
### Properties
* **scope**: string (Required): Target scope for Azure resources to be deployed into.  For example: '/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/testGroup'.

## Recipe
### Properties
* **name**: string (Required): The name of the recipe within the environment to use
* **parameters**: any: Any object

## RecipeConfigProperties
### Properties
* **bicep**: [BicepConfigProperties](#bicepconfigproperties): Configuration for Bicep Recipes. Controls how Bicep plans and applies templates as part of Recipe deployment.
* **env**: [EnvironmentVariables](#environmentvariables): The environment variables injected during Terraform Recipe execution for the recipes in the environment.
* **envSecrets**: [RecipeConfigPropertiesEnvSecrets](#recipeconfigpropertiesenvsecrets): Environment variables containing sensitive information can be stored as secrets. The secrets are stored in Applications.Core/SecretStores resource.
* **terraform**: [TerraformConfigProperties](#terraformconfigproperties): Configuration for Terraform Recipes. Controls how Terraform plans and applies templates as part of Recipe deployment.

## RecipeConfigPropertiesEnvSecrets
### Properties
### Additional Properties
* **Additional Properties Type**: [SecretReference](#secretreference)

## RecipeProperties
* **Discriminator**: templateKind

### Base Properties
* **parameters**: any: Any object
* **templatePath**: string (Required): Path to the template provided by the recipe. Currently only link to Azure Container Registry is supported.
* **tls**: [TLSConfig](#tlsconfig): TLS configuration options for HTTPS connections.

### BicepRecipeProperties
#### Properties
* **plainHttp**: bool: Connect to the Bicep registry using HTTP (not-HTTPS). This should be used when the registry is known not to support HTTPS, for example in a locally-hosted registry. Defaults to false (use HTTPS/TLS).
* **templateKind**: 'bicep' (Required): Discriminator property for RecipeProperties.

### TerraformRecipeProperties
#### Properties
* **templateKind**: 'terraform' (Required): Discriminator property for RecipeProperties.
* **templateVersion**: string: Version of the template to deploy. For Terraform recipes using a module registry this is required, but must be omitted for other module sources.


## RecipeStatus
### Properties
* **templateKind**: string (Required): TemplateKind is the kind of the recipe template used by the portable resource upon deployment.
* **templatePath**: string (Required): TemplatePath is the path of the recipe consumed by the portable resource upon deployment.
* **templateVersion**: string: TemplateVersion is the version number of the template.

## RegistryAuthConfig
### Properties
* **additionalHosts**: string[]: Additional hosts that should use the same authentication credentials. This is useful when a registry mirror redirects to other hosts (e.g., GitLab Pages mirrors redirecting to gitlab.com).
* **token**: [TokenConfig](#tokenconfig): Token authentication configuration.

## RegistrySecretConfig
### Properties
* **secret**: string: The ID of an Applications.Core/SecretStore resource containing credential information used to authenticate private container registry.The keys in the secretstore depends on the type.

## ResourceReference
### Properties
* **id**: string (Required): Resource id of an existing resource

## ResourceStatus
### Properties
* **compute**: [EnvironmentCompute](#environmentcompute): Represents backing compute resource
* **outputResources**: [OutputResource](#outputresource)[]: Properties of an output resource
* **recipe**: [RecipeStatus](#recipestatus) (ReadOnly): Recipe status at deployment time for a resource.

## RuntimesProperties
### Properties
* **aci**: [ACIRuntimeProperties](#aciruntimeproperties): The runtime configuration properties for Kubernetes
* **kubernetes**: [KubernetesRuntimeProperties](#kubernetesruntimeproperties): The runtime configuration properties for Kubernetes

## SecretConfig
### Properties
* **secret**: string: The ID of an Applications.Core/SecretStore resource containing the Git platform personal access token (PAT). The secret store must have a secret named 'pat', containing the PAT value. A secret named 'username' is optional, containing the username associated with the pat. By default no username is specified.

## SecretObjectProperties
### Properties
* **alias**: string: File name when written to disk
* **encoding**: 'base64' | 'hex' | 'utf-8': Encoding format. Default utf-8
* **name**: string (Required): The name of the secret
* **version**: string: secret version

## SecretReference
### Properties
* **key**: string (Required): The key for the secret in the secret store.
* **source**: string (Required): The ID of an Applications.Core/SecretStore resource containing sensitive data required for recipe execution.

## SecretStoreProperties
### Properties
* **application**: string: Fully qualified resource ID for the application
* **data**: [SecretStorePropertiesData](#secretstorepropertiesdata) (Required): An object to represent key-value type secrets
* **environment**: string: Fully qualified resource ID for the environment that the application is linked to
* **provisioningState**: 'Accepted' | 'Canceled' | 'Creating' | 'Deleting' | 'Failed' | 'Provisioning' | 'Succeeded' | 'Updating' (ReadOnly): Provisioning state of the resource at the time the operation was called
* **resource**: string: The resource id of external secret store.
* **status**: [ResourceStatus](#resourcestatus) (ReadOnly): Status of a resource.
* **type**: 'awsIRSA' | 'azureWorkloadIdentity' | 'basicAuthentication' | 'certificate' | 'generic': The type of SecretStore data

## SecretStorePropertiesData
### Properties
### Additional Properties
* **Additional Properties Type**: [SecretValueProperties](#secretvalueproperties)

## SecretValueProperties
### Properties
* **encoding**: 'base64' | 'raw': The type of SecretValue Encoding
* **value**: string: The value of secret.
* **valueFrom**: [ValueFromProperties](#valuefromproperties): The Secret value source properties

## SystemData
### Properties
* **createdAt**: string: The timestamp of resource creation (UTC).
* **createdBy**: string: The identity that created the resource.
* **createdByType**: 'Application' | 'Key' | 'ManagedIdentity' | 'User': The type of identity that created the resource.
* **lastModifiedAt**: string: The timestamp of resource last modification (UTC)
* **lastModifiedBy**: string: The identity that last modified the resource.
* **lastModifiedByType**: 'Application' | 'Key' | 'ManagedIdentity' | 'User': The type of identity that created the resource.

## TerraformConfigProperties
### Properties
* **authentication**: [AuthConfig](#authconfig): Authentication information used to access private Terraform module sources. Supported module sources: Git.
* **moduleRegistries**: [TerraformConfigPropertiesModuleRegistries](#terraformconfigpropertiesmoduleregistries): Configuration for Terraform module registries. Allows overriding the default Terraform module registry with a custom registry.
* **providerMirror**: [TerraformProviderMirrorConfig](#terraformprovidermirrorconfig): Configuration for a Terraform provider mirror. Allows overriding the default Terraform provider registry with a custom mirror.
* **providers**: [TerraformConfigPropertiesProviders](#terraformconfigpropertiesproviders): Configuration for Terraform Recipe Providers. Controls how Terraform interacts with cloud providers, SaaS providers, and other APIs. For more information, please see: https://developer.hashicorp.com/terraform/language/providers/configuration.
* **version**: [TerraformVersionConfig](#terraformversionconfig): Configuration for Terraform binary installation. Allows specifying a version and an optional custom base URL for the releases API.

## TerraformConfigPropertiesModuleRegistries
### Properties
### Additional Properties
* **Additional Properties Type**: [TerraformModuleRegistryConfig](#terraformmoduleregistryconfig)

## TerraformConfigPropertiesProviders
### Properties
### Additional Properties
* **Additional Properties Type**: [ProviderConfigProperties](#providerconfigproperties)[]

## TerraformModuleRegistryConfig
### Properties
* **authentication**: [RegistryAuthConfig](#registryauthconfig): Authentication configuration for accessing private Terraform registry mirrors.
* **tls**: [TLSConfig](#tlsconfig): TLS configuration options for HTTPS connections.
* **url**: string (Required): The base URL of the module registry. Example: 'https://terraform.example.com'

## TerraformProviderMirrorConfig
### Properties
* **authentication**: [RegistryAuthConfig](#registryauthconfig): Authentication configuration for accessing private Terraform registry mirrors.
* **tls**: [TLSConfig](#tlsconfig): TLS configuration options for HTTPS connections.
* **url**: string (Required): The base URL of the provider mirror. Example: 'https://terraform.example.com'

## TerraformVersionConfig
### Properties
* **authentication**: [RegistryAuthConfig](#registryauthconfig): Authentication configuration for accessing private Terraform registry mirrors.
* **releasesApiBaseUrl**: string: Optional base URL for a custom Terraform releases API. If set, Terraform will be downloaded from this base URL instead of the default HashiCorp releases site. The directory structure of the custom URL must match the HashiCorp releases site (including the index.json files). Example: 'https://my-terraform-mirror.example.com'
* **releasesArchiveUrl**: string: Optional direct URL to a Terraform binary archive (.zip file). If set, Terraform will be downloaded directly from this URL instead of using the releases API. This takes precedence over releasesApiBaseUrl. The URL must point to a valid Terraform release archive. Example: 'https://my-mirror.example.com/terraform/1.7.0/terraform_1.7.0_linux_amd64.zip'
* **tls**: [TLSConfig](#tlsconfig): TLS configuration options for HTTPS connections.
* **version**: string: Specific version of the Terraform binary to install. If omitted, the system may default to the latest stable version. Example: '1.7.0'

## TLSConfig
### Properties
* **caCertificate**: [SecretReference](#secretreference): This secret is used within a recipe. Secrets are encrypted, often have fine-grained access control, auditing and are recommended to be used to hold sensitive data.
* **skipVerify**: bool: Allows insecure connections (skip TLS verification). This is strongly discouraged in production environments. WARNING: This makes the connection vulnerable to man-in-the-middle attacks.

## TokenConfig
### Properties
* **secret**: string: The ID of an Applications.Core/SecretStore resource containing the authentication token. The secret store must have a secret named 'token' containing the token value.

## TrackedResourceTags
### Properties
### Additional Properties
* **Additional Properties Type**: string

## TrackedResourceTags
### Properties
### Additional Properties
* **Additional Properties Type**: string

## TrackedResourceTags
### Properties
### Additional Properties
* **Additional Properties Type**: string

## TrackedResourceTags
### Properties
### Additional Properties
* **Additional Properties Type**: string

## TrackedResourceTags
### Properties
### Additional Properties
* **Additional Properties Type**: string

## TrackedResourceTags
### Properties
### Additional Properties
* **Additional Properties Type**: string

## TrackedResourceTags
### Properties
### Additional Properties
* **Additional Properties Type**: string

## ValueFromProperties
### Properties
* **name**: string (Required): The name of the referenced secret.
* **version**: string: The version of the referenced secret.

## Volume
* **Discriminator**: kind

### Base Properties
* **mountPath**: string: The path where the volume is mounted

### EphemeralVolume
#### Properties
* **kind**: 'ephemeral' (Required): Discriminator property for Volume.
* **managedStore**: 'disk' | 'memory' (Required): The managed store for the ephemeral volume

### PersistentVolume
#### Properties
* **kind**: 'persistent' (Required): Discriminator property for Volume.
* **permission**: 'read' | 'write': The persistent volume permission
* **source**: string (Required): The source of the volume


## VolumeProperties
* **Discriminator**: kind

### Base Properties
* **application**: string (Required): Fully qualified resource ID for the application
* **environment**: string: Fully qualified resource ID for the environment that the application is linked to
* **provisioningState**: 'Accepted' | 'Canceled' | 'Creating' | 'Deleting' | 'Failed' | 'Provisioning' | 'Succeeded' | 'Updating' (ReadOnly): Provisioning state of the resource at the time the operation was called
* **status**: [ResourceStatus](#resourcestatus) (ReadOnly): Status of a resource.

### AzureKeyVaultVolumeProperties
#### Properties
* **certificates**: [AzureKeyVaultVolumePropertiesCertificates](#azurekeyvaultvolumepropertiescertificates): The KeyVault certificates that this volume exposes
* **keys**: [AzureKeyVaultVolumePropertiesKeys](#azurekeyvaultvolumepropertieskeys): The KeyVault keys that this volume exposes
* **kind**: 'azure.com.keyvault' (Required): Discriminator property for VolumeProperties.
* **resource**: string (Required): The ID of the keyvault to use for this volume resource
* **secrets**: [AzureKeyVaultVolumePropertiesSecrets](#azurekeyvaultvolumepropertiessecrets): The KeyVault secrets that this volume exposes


